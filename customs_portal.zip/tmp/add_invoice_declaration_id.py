import mysql.connector

cfg = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

conn = mysql.connector.connect(**cfg)
cur = conn.cursor()
try:
    cur.execute("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_invoices' AND column_name='declaration_id'", (cfg['database'],))
    exists = cur.fetchone()[0]
    if not exists:
        print('Adding declaration_id column to customs_invoices...')
        cur.execute("ALTER TABLE customs_invoices ADD COLUMN declaration_id INT DEFAULT NULL")
        # optional foreign key - comment out if not desired
        try:
            cur.execute("ALTER TABLE customs_invoices ADD CONSTRAINT fk_invoice_declaration FOREIGN KEY (declaration_id) REFERENCES customs_declarations(id) ON DELETE SET NULL")
        except Exception as e:
            print('Could not add foreign key (may already exist or missing privileges):', e)
        conn.commit()
        print('Done.')
    else:
        print('declaration_id column already exists.')
finally:
    cur.close()
    conn.close()
