import mysql.connector

cfg = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

conn = mysql.connector.connect(**cfg)
cur = conn.cursor(dictionary=True)
try:
    cur.execute("SELECT * FROM customs_invoices WHERE invoice_no LIKE 'TESTINV-%' ORDER BY id DESC LIMIT 1")
    inv = cur.fetchone()
    if not inv:
        print('No TESTINV-* invoice found.')
    else:
        print('Invoice:')
        print('  id:', inv['id'])
        print('  invoice_no:', inv['invoice_no'])
        print('  invoice_type:', inv['invoice_type'])
        print('  invoice_date:', inv['invoice_date'])
        print('  party:', inv['party'])
        print('  notes:', inv['notes'])
        print('  total_amount:', inv['total_amount'])
        print('  created_by:', inv['created_by'])
        print('  declaration_id:', inv.get('declaration_id'))

        # lookup declaration ACID
        if inv.get('declaration_id'):
            cur.execute('SELECT declaration_no, acid FROM customs_declarations WHERE id=%s', (inv['declaration_id'],))
            d = cur.fetchone()
            if d:
                print('  linked declaration_no:', d.get('declaration_no'))
                print('  linked ACID:', d.get('acid'))

        # items
        cur.execute('SELECT ci.*, u.unit_name, it.item_name_ar FROM customs_invoice_items ci LEFT JOIN units u ON u.id=ci.unit_id LEFT JOIN items it ON it.id=ci.item_id WHERE ci.invoice_id=%s', (inv['id'],))
        items = cur.fetchall()
        print('\nItems:')
        for it in items:
            print('  - id:', it['id'])
            print('    item_id:', it['item_id'], 'name:', it.get('item_name_ar'))
            print('    qty:', it['quantity'], 'unit_price:', it['unit_price'], 'unit:', it.get('unit_name'))
            print('    description:', it['description'])

except Exception as e:
    print('Error querying DB:', e)
finally:
    cur.close()
    conn.close()
