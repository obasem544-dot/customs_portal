import mysql.connector

cfg = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

conn = mysql.connector.connect(**cfg)
cur = conn.cursor()
try:
    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_declarations'", (cfg['database'],))
    existing = [row[0] for row in cur.fetchall()]
    print('EXISTING COLUMNS:', existing)

    additions = [
        ('regime_type', "ALTER TABLE customs_declarations ADD COLUMN regime_type varchar(100) DEFAULT NULL"),
        ('regime_details', "ALTER TABLE customs_declarations ADD COLUMN regime_details text DEFAULT NULL"),
        ('tax_card_number', "ALTER TABLE customs_declarations ADD COLUMN tax_card_number varchar(100) DEFAULT NULL"),
        ('commercial_register_number', "ALTER TABLE customs_declarations ADD COLUMN commercial_register_number varchar(100) DEFAULT NULL")
    ]

    for name, sql in additions:
        if name not in existing:
            print('Adding column:', name)
            cur.execute(sql)
        else:
            print('Already exists:', name)
    conn.commit()

    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_declarations' ORDER BY ordinal_position", (cfg['database'],))
    print('FINAL COLUMNS:', [row[0] for row in cur.fetchall()])
finally:
    cur.close()
    conn.close()
