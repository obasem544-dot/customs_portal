from werkzeug.security import generate_password_hash
import mysql.connector

db_config = {'host':'localhost','user':'root','password':'Hazem@2026','database':'customs_portal'}
conn = mysql.connector.connect(**db_config)
cur = conn.cursor()
username='autotest'
cur.execute("SELECT id FROM users WHERE username=%s", (username,))
if cur.fetchone():
    print('user exists')
else:
    pw = 'password123'
    ph = generate_password_hash(pw)
    cur.execute("INSERT INTO users (username, password_hash, status, created_at) VALUES (%s,%s,%s,NOW())", (username, ph, 'active'))
    conn.commit()
    print('created', username, pw)
cur.close()
conn.close()
