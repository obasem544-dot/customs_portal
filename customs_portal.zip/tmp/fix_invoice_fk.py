import mysql.connector

cfg = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

conn = mysql.connector.connect(**cfg)
cur = conn.cursor()
try:
    def get_col_info(table, column):
        cur.execute("""
            SELECT COLUMN_TYPE, DATA_TYPE, IS_NULLABLE, COLUMN_KEY, EXTRA
            FROM information_schema.columns
            WHERE table_schema=%s AND table_name=%s AND column_name=%s
        """, (cfg['database'], table, column))
        return cur.fetchone()

    decl = get_col_info('customs_declarations', 'id')
    inv = get_col_info('customs_invoices', 'declaration_id')

    print('customs_declarations.id ->', decl)
    print('customs_invoices.declaration_id ->', inv)

    if not decl:
        print('ERROR: customs_declarations.id not found. Aborting.')
    else:
        decl_type = decl[0]  # COLUMN_TYPE e.g. 'int(11) unsigned'
        if not inv:
            print('declaration_id does not exist on customs_invoices, creating with type', decl_type)
            cur.execute(f"ALTER TABLE customs_invoices ADD COLUMN declaration_id {decl_type} DEFAULT NULL")
            conn.commit()
            print('column added')
            inv = get_col_info('customs_invoices', 'declaration_id')
        else:
            inv_type = inv[0]
            if inv_type != decl_type:
                print('Types differ, altering declaration_id from', inv_type, 'to', decl_type)
                cur.execute(f"ALTER TABLE customs_invoices MODIFY COLUMN declaration_id {decl_type} DEFAULT NULL")
                conn.commit()
                print('column modified')
            else:
                print('Column types already match')

        # attempt to drop existing FK named fk_invoice_declaration if exists
        try:
            print('Attempting to drop existing foreign key fk_invoice_declaration (if any)')
            cur.execute("ALTER TABLE customs_invoices DROP FOREIGN KEY fk_invoice_declaration")
            print('Dropped existing fk_invoice_declaration')
        except Exception as e:
            print('No existing named foreign key to drop or drop failed (ok):', e)

        # now add the FK
        try:
            print('Adding foreign key fk_invoice_declaration')
            cur.execute("ALTER TABLE customs_invoices ADD CONSTRAINT fk_invoice_declaration FOREIGN KEY (declaration_id) REFERENCES customs_declarations(id) ON DELETE SET NULL")
            conn.commit()
            print('Foreign key added successfully')
        except Exception as e:
            print('Failed to add foreign key:', e)

finally:
    cur.close()
    conn.close()
