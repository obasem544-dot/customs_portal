import mysql.connector
import datetime

cfg = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

conn = mysql.connector.connect(**cfg)
cur = conn.cursor(dictionary=True)
try:
    # find an existing declaration
    cur.execute("SELECT id, declaration_no, acid FROM customs_declarations ORDER BY id LIMIT 1")
    decl = cur.fetchone()
    if not decl:
        # create a minimal declaration
        decl_no = 'TEST-DECL-' + datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        cur.execute("INSERT INTO customs_declarations (declaration_no, created_at) VALUES (%s, NOW())", (decl_no,))
        declaration_id = cur.lastrowid
        conn.commit()
        print('Inserted test declaration id=', declaration_id)
        cur.execute("SELECT id, declaration_no, acid FROM customs_declarations WHERE id=%s", (declaration_id,))
        decl = cur.fetchone()
    else:
        declaration_id = decl['id']
        print('Found existing declaration id=', declaration_id)

    # create test invoice
    now = datetime.datetime.now()
    invoice_no = 'TESTINV-' + now.strftime('%Y%m%d%H%M%S')
    invoice_date = now.date().isoformat()
    party = 'Test Party'
    notes = 'Inserted by automated test script'

    cur.execute("INSERT INTO customs_invoices (invoice_no, invoice_type, invoice_date, party, notes, created_by, declaration_id, created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())",
                (invoice_no, 'export_invoice', invoice_date, party, notes, 'system', declaration_id))
    invoice_id = cur.lastrowid

    # insert one item
    qty = 2
    unit_price = 123.45
    cur.execute("INSERT INTO customs_invoice_items (invoice_id, item_id, quantity, unit_price, unit_id, description) VALUES (%s,%s,%s,%s,%s,%s)",
                (invoice_id, None, qty, unit_price, None, 'Automated test item'))

    total = qty * unit_price
    cur.execute("UPDATE customs_invoices SET total_amount=%s WHERE id=%s", (total, invoice_id))
    conn.commit()

    # fetch and print invoice and items
    cur.execute("SELECT * FROM customs_invoices WHERE id=%s", (invoice_id,))
    inv = cur.fetchone()
    print('\nInserted invoice:')
    for k, v in inv.items():
        print(f"  {k}: {v}")

    cur.execute("SELECT * FROM customs_invoice_items WHERE invoice_id=%s", (invoice_id,))
    items = cur.fetchall()
    print('\nInserted items:')
    for it in items:
        print(it)

except Exception as e:
    conn.rollback()
    print('Error:', e)
finally:
    cur.close()
    conn.close()
