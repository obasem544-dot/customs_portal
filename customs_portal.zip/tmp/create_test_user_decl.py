import mysql.connector
from werkzeug.security import generate_password_hash
from datetime import datetime

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

conn = mysql.connector.connect(**db_config)
cur = conn.cursor(dictionary=True)

# ensure a user exists
cur.execute("SELECT id, username FROM users WHERE status='active' LIMIT 1")
user = cur.fetchone()
created_user = None
if not user:
    pw = 'password123'
    ph = generate_password_hash(pw)
    cur.execute("INSERT INTO users (username, password_hash, status, created_at) VALUES (%s,%s,%s,NOW())", ('testadmin', ph, 'active'))
    conn.commit()
    cur.execute("SELECT id, username FROM users WHERE username='testadmin'")
    user = cur.fetchone()
    created_user = ('testadmin', pw)

# ensure at least one item
cur.execute("SELECT id FROM items LIMIT 1")
item = cur.fetchone()
if not item:
    cur.execute("INSERT INTO items (item_name_ar, current_stock, current_balance, unit_id) VALUES (%s,%s,%s,%s)", ('بند تجريبي', 100, 100, None))
    conn.commit()
    cur.execute("SELECT id FROM items ORDER BY id DESC LIMIT 1")
    item = cur.fetchone()

# ensure at least one declaration with items
cur.execute("SELECT id FROM customs_declarations LIMIT 1")
decl = cur.fetchone()
if not decl:
    cur.execute("INSERT INTO customs_declarations (declaration_no, declaration_date, importer_name, created_by, created_at) VALUES (%s,%s,%s,%s,NOW())", ('TEST-DECL-1', datetime.now().strftime('%Y-%m-%d'), 'شركة تجريبية', user['username']))
    conn.commit()
    decl_id = cur.lastrowid
    cur.execute("INSERT INTO customs_items (declaration_id, item_id, quantity, unit_price, description) VALUES (%s,%s,%s,%s,%s)", (decl_id, item['id'], 10, 5.0, 'بند تجريبي'))
    conn.commit()
    decl = {'id': decl_id}

print('user:', user)
if created_user:
    print('created_user_credentials:', created_user)
print('item_id:', item['id'])
print('declaration_id:', decl['id'])

cur.close()
conn.close()
