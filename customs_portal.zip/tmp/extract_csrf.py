import re
s=open('tmp\\login.html','r',encoding='utf-8').read()
m=re.search(r'name="csrf_token" value="([^"]+)"',s)
print(m.group(1) if m else '')
