import mysql.connector
from app import app

# disable CSRF for this validation script
app.config['WTF_CSRF_ENABLED'] = False

conn = mysql.connector.connect(host='localhost', user='root', password='Hazem@2026', database='customs_portal')
cur = conn.cursor(dictionary=True)
cur.execute('SELECT id FROM items ORDER BY id LIMIT 1')
item = cur.fetchone()
cur.execute('SELECT id FROM units ORDER BY id LIMIT 1')
unit = cur.fetchone()
conn.close()

if not item or not unit:
    raise RuntimeError(f'Missing item/unit: item={item}, unit={unit}')

with app.test_client() as client:
    login = client.post('/', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=False)
    print('login_status=', login.status_code)
    print('login_location=', login.headers.get('Location'))

    data = {
        'declaration_no': 'CUS-TEST-201',
        'declaration_date': '2026-09-11',
        'status': 'pending',
        'acid': 'ACID-TEST-201',
        'inbound_type': 'external',
        'importer_name': 'شركة تجريبية للنقل',
        'exporter_name': 'مصدر تجريبي',
        'origin_country': 'تركيا',
        'destination_country': 'مصر',
        'regime_type': 'import',
        'regime_details': 'ميناء',
        'port_of_discharge': 'ميناء الإسكندرية',
        'total_weight': '125.50',
        'package_count': '12',
        'clearance_officer_name': 'أحمد محمد',
        'clearance_officer_location': 'المنطقة الحرة',
        'clearance_officer_phone': '01000000000',
        'tax_card_number': 'TAX-1001',
        'commercial_register_number': 'CR-2001',
        'currency': 'USD',
        'total_value': '2500.00',
        'customs_fee': '180.00',
        'notes': 'وارد تجريبي تم إنشاؤه عبر الاختبار',
        'item_id[]': [str(item['id'])],
        'serial_number[]': ['SER-TEST-201'],
        'unit_price[]': ['200.00'],
        'origin[]': ['تركيا'],
        'qty[]': ['10'],
        'unit_id[]': [str(unit['id'])],
        'description[]': ['مياه معدنية'],
    }

    resp = client.post('/customs-management/new', data=data, follow_redirects=False)
    print('entry_status=', resp.status_code)
    print('entry_location=', resp.headers.get('Location'))
    print('response_snippet=', resp.data.decode('utf-8', 'ignore')[:400])

conn = mysql.connector.connect(host='localhost', user='root', password='Hazem@2026', database='customs_portal')
cur = conn.cursor(dictionary=True)
cur.execute('SELECT id, declaration_no, acid, importer_name, status, created_by FROM customs_declarations WHERE declaration_no=%s LIMIT 1', ('CUS-TEST-201',))
print('db_row=', cur.fetchone())
cur.close(); conn.close()
