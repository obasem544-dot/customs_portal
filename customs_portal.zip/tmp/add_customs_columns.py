import mysql.connector

cfg = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

conn = mysql.connector.connect(**cfg)
cur = conn.cursor()
try:
    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_declarations' ORDER BY ordinal_position", (cfg['database'],))
    existing = [row[0] for row in cur.fetchall()]
    print('EXISTING COLUMNS:', existing)

    additions = [
        ('acid', "ALTER TABLE customs_declarations ADD COLUMN acid varchar(100) DEFAULT NULL"),
        ('inbound_type', "ALTER TABLE customs_declarations ADD COLUMN inbound_type varchar(100) DEFAULT NULL"),
        ('port_of_loading', "ALTER TABLE customs_declarations ADD COLUMN port_of_loading varchar(255) DEFAULT NULL"),
        ('port_of_destination', "ALTER TABLE customs_declarations ADD COLUMN port_of_destination varchar(255) DEFAULT NULL"),
        ('port_of_discharge', "ALTER TABLE customs_declarations ADD COLUMN port_of_discharge varchar(255) DEFAULT NULL"),
        ('total_weight', "ALTER TABLE customs_declarations ADD COLUMN total_weight decimal(18,2) DEFAULT 0.00"),
        ('package_count', "ALTER TABLE customs_declarations ADD COLUMN package_count int DEFAULT 0"),
        ('currency', "ALTER TABLE customs_declarations ADD COLUMN currency varchar(10) DEFAULT NULL"),
        ('notes', "ALTER TABLE customs_declarations ADD COLUMN notes text DEFAULT NULL")
    ]

    # Also ensure customs_items has fields for item details (description, serial, origin, unit_id)
    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_items'", (cfg['database'],))
    existing_items_cols = [row[0] for row in cur.fetchall()]

    additions_items = [
        ('description', "ALTER TABLE customs_items ADD COLUMN description varchar(255) DEFAULT NULL"),
        ('serial_number', "ALTER TABLE customs_items ADD COLUMN serial_number varchar(255) DEFAULT NULL"),
        ('origin_country', "ALTER TABLE customs_items ADD COLUMN origin_country varchar(100) DEFAULT NULL"),
        ('unit_id', "ALTER TABLE customs_items ADD COLUMN unit_id int DEFAULT NULL")
    ]

    for name, sql in additions:
        if name not in existing:
            print('Adding column:', name)
            cur.execute(sql)
        else:
            print('Already exists:', name)
    conn.commit()

    # Add item columns
    for name, sql in additions_items:
        if name not in existing_items_cols:
            print('Adding customs_items column:', name)
            cur.execute(sql)
        else:
            print('Already exists in customs_items:', name)
    conn.commit()

    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_declarations' ORDER BY ordinal_position", (cfg['database'],))
    print('FINAL COLUMNS (declarations):', [row[0] for row in cur.fetchall()])
    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_items' ORDER BY ordinal_position", (cfg['database'],))
    print('FINAL COLUMNS (customs_items):', [row[0] for row in cur.fetchall()])

    for name, sql in additions:
        if name not in existing:
            print('Adding column:', name)
            cur.execute(sql)
        else:
            print('Already exists:', name)
    conn.commit()

    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name='customs_declarations' ORDER BY ordinal_position", (cfg['database'],))
    print('FINAL COLUMNS:', [row[0] for row in cur.fetchall()])
finally:
    cur.close()
    conn.close()
