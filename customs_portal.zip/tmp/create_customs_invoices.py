import mysql.connector

cfg = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hazem@2026',
    'database': 'customs_portal'
}

create_invoices = """
CREATE TABLE IF NOT EXISTS customs_invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(100),
    invoice_type VARCHAR(50),
    invoice_date DATE,
    party VARCHAR(255),
    notes TEXT,
    total_amount DECIMAL(18,2) DEFAULT 0.00,
    created_by VARCHAR(100),
    created_at DATETIME DEFAULT NOW(),
    updated_at DATETIME DEFAULT NOW() ON UPDATE NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""

create_items = """
CREATE TABLE IF NOT EXISTS customs_invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    item_id INT DEFAULT NULL,
    quantity DECIMAL(18,4) DEFAULT 0.0000,
    unit_price DECIMAL(18,4) DEFAULT 0.0000,
    unit_id INT DEFAULT NULL,
    description VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (invoice_id) REFERENCES customs_invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""

conn = mysql.connector.connect(**cfg)
cur = conn.cursor()
try:
    print('Creating tables if not exist...')
    cur.execute(create_invoices)
    cur.execute(create_items)
    conn.commit()
    print('Done. Tables created or already exist.')
finally:
    cur.close()
    conn.close()
